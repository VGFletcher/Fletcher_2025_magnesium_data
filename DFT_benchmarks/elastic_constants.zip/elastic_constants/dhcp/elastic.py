import sys
import ase
import ase.calculators.castep
import ase.io.castep, ase.io
from ase.constraints import UnitCellFilter
from ase.optimize import LBFGS

import matscipy
from matscipy.elasticity import fit_elastic_constants

calc = ase.calculators.castep.Castep(
                        castep_command="srun -n 48 --cpu-bind=rank castep.mpi",
                        castep_pp_path="/castep/elastic_const/",
                        find_pspots=True,
                        cut_off_energy=700,
                        spin_polarized=False,
                        opt_strategy='speed',
                        xc_functional='PBE',
                        elec_energy_tol=1.0e-9,
                        max_scf_cycles=150,
                        fix_occupancy=False,
                        calculate_stress=True,
                        finite_basis_corr='automatic',
                        smearing_width='0.2',
                        fine_grid_scale=4.0,
                        mixing_scheme='broyden',
                        mix_history_length=7,
                        num_dump_cycles=0,
                        kpoints_mp_grid='38 38 10',
                        nextra_bands=17)

a = ase.io.read(f"dhcp_0.cell", index=-1)
a.calc = calc

print('Beginning Elastic Calc')
C = fit_elastic_constants(a, symmetry='trigonal_high', delta=5.0e-5)
print(C)
print('Finished Elastic Calc')
